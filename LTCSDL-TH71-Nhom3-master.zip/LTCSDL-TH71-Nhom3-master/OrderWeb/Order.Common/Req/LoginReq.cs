using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Common.Req
{
  public class LoginReq
  {
    public string email { get; set; }
    public string password { get; set; }
  }
}
