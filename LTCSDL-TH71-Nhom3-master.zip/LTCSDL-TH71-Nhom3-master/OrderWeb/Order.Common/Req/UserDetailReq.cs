﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Common.Req
{
     public class UserDetailReq
    {
        public string MaLoaiLogin { get; set; }
        public string MaNguoiDung { get; set; }
        public string DiaChi { get; set; }
        public string Sdt { get; set; }
        public string GhiChu { get; set; }

       
    }
}
