﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Common.Req
{
   public class LoaiThucAnReq
    {
        public string MaLoai { get; set; }
        public string TenLoaiThucAn { get; set; }
        public string GhiChu { get; set; }
    }
}
